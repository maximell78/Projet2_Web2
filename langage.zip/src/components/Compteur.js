
const Compteur = ({ createElement, value, increment }) => (
    <button onClick={increment} className="btn btn-success">Cliquez ici</button>
  )
  export default Compteur